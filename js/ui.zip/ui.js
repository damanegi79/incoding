// JavaScript Document
isMobile = {
    Android: function () {
                return navigator.userAgent.match(/Android/i) == null ? false : true;
    },
    BlackBerry: function () {
                return navigator.userAgent.match(/BlackBerry/i) == null ? false : true;
    },
    IOS: function () {
                return navigator.userAgent.match(/iPhone|iPad|iPod/i) == null ? false : true;
    },
    Opera: function () {
                return navigator.userAgent.match(/Opera Mini/i) == null ? false : true;
    },
    Windows: function () {
                return navigator.userAgent.match(/IEMobile/i) == null ? false : true;
    },
    any: function () {
                return (isMobile.Android() || isMobile.BlackBerry() || isMobile.IOS() || isMobile.Opera() || isMobile.Windows());
    }
};

window.onLoad = function() {        
    window.scrollTo(0,1);
}
$(document).ready(function(){
    init()
    title()
})

$(window).resize(function(){
    title()
})

function title(){
    var conNum = $('.workList').width()
    var conNumList = $('.grid').width()
    var sizeNum = $(window).width()
    var titleSize = (sizeNum - conNum) / 2
    var titleSize01 = (sizeNum - conNumList) / 2
    $('.workHeader, .select_image').css({left:titleSize + 20}) // 
    $('.select_list').css({left:titleSize01+20}) // 
    
}


function init(){
    $('.pressList li a').on('mouseover',function(){
       $('.pressList li').removeClass('on')
       $(this).parent().addClass('on')
   })
    $('#header .menu button').on('click',function(){
       $('#header').addClass('active')
   })
    $('#header .closeMenu button').on('click',function(){
       $('#header').removeClass('active')
   })
    $('.detailContents .more button').on('click',function(){
       $('.detailContents').addClass('active')
   })
    
    
    $('.block_white .bg').animate({marginTop:'0'},300,'easeInOutQuart',function(){
        $('.block_white').delay(500).animate({height:'0'},500,'easeInOutQuart')
        $('.block_white .bg').delay(500).animate({height:'0'},500,'easeInOutQuart')
    })
    $('#wrapper, #footer').delay(500).animate({opacity:1},1500)
    $('.btnTop').each(function(){
        $(this).click(function(){ 
            $('html,body').animate({ scrollTop: 0 }, 'slow');
            return false; 
        });
    });
    $(window).scroll(function(){
        var scrollY = $(window).scrollTop()
        if(scrollY>100){
            $('.btnTop').fadeIn(400)
        } else if(scrollY<100){
            $('.btnTop').fadeOut(400)
        }
    })
    $(window).scroll(function () {
        var win = $(window).scrollTop();
        var newValueY = -(win/4)
        $(".aboutVisual").css('background-position-y', newValueY)
    });
}


$(document).ready(function(){
    var didScroll;
    var lastScrollTop = 0;
    var delta = 5;
    var navbarHeight = $('#header').outerHeight();

    $(window).scroll(function(event){
        didScroll = true;
    });

    setInterval(function() {
        if (didScroll) {
            hasScrolled();
            didScroll = false;
        }
    }, 250);
    function hasScrolled() {
        if($('#header').length == 1){
            
           
        var st = $(this).scrollTop();

        // Make sure they scroll more than delta
        if(Math.abs(lastScrollTop - st) <= delta)
            return;

        // If they scrolled down and are past the navbar, add class .nav-up.
        // This is necessary so you never see what is "behind" the navbar.
        if (st > lastScrollTop && st > navbarHeight){
            // Scroll Down
            $('#header').removeClass('nav-down').addClass('nav-up');
            
        } else {
            // Scroll Up
            if(st + $(window).height() < $(document).height()) {
                $('#header').removeClass('nav-up').addClass('nav-down');
                
            }
        }

        lastScrollTop = st;
            }
    }
})

